
-- ------------------------------------------------------------
--  Dump de banco de dados SIMULADO
--  Sistema de Cadastro e Agendamento de Serviços Comunitários
-- ------------------------------------------------------------

DROP DATABASE IF EXISTS servicos_comunitarios;
CREATE DATABASE servicos_comunitarios;
USE servicos_comunitarios;

-- ============================================================
-- Tabela: usuarios (administradores, voluntários, cidadãos)
-- ============================================================
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    telefone VARCHAR(20),
    tipo ENUM('cidadao','voluntario','admin') DEFAULT 'cidadao',
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO usuarios (nome, email, senha, telefone, tipo) VALUES
('Gustavo Macedo', 'gustavo@example.com', 'senha_hash_1', '11999999999', 'admin'),
('Priscila Andrade', 'priscila@example.com', 'senha_hash_2', '11988887777', 'voluntario'),
('Marcos Santos', 'marcos@example.com', 'senha_hash_3', '11977776666', 'cidadao'),
('Joana Lima', 'joana@example.com', 'senha_hash_4', '11966665555', 'cidadao');

-- ============================================================
-- Tabela: servicos (tipos de serviços comunitários)
-- ============================================================
CREATE TABLE servicos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    descricao TEXT,
    categoria VARCHAR(100),
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO servicos (nome, descricao, categoria) VALUES
('Limpeza de praça', 'Mutirão de limpeza de praças públicas', 'ambiental'),
('Reforma comunitária', 'Pequenas reformas em instituições sociais', 'infraestrutura'),
('Doação de alimentos', 'Organização e distribuição de cestas básicas', 'social'),
('Pintura de escolas', 'Pintura e manutenção básica em escolas municipais', 'educacao');

-- ============================================================
-- Tabela: locais (onde ocorrem os serviços)
-- ============================================================
CREATE TABLE locais (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    endereco VARCHAR(255),
    bairro VARCHAR(120),
    cidade VARCHAR(120) DEFAULT 'São Paulo',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO locais (nome, endereco, bairro) VALUES
('Praça Central', 'Rua das Flores, 120', 'Centro'),
('Escola Municipal Aurora', 'Av. Brasil, 450', 'Jardim Brasil'),
('Centro Comunitário Boa Esperança', 'Rua Verde, 300', 'Vila Nova');

-- ============================================================
-- Tabela: agendamentos (cidadãos marcando serviços)
-- ============================================================
CREATE TABLE agendamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    servico_id INT NOT NULL,
    local_id INT NOT NULL,
    data_agendada DATE NOT NULL,
    horario TIME NOT NULL,
    status ENUM('pendente','confirmado','concluido','cancelado') DEFAULT 'pendente',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (servico_id) REFERENCES servicos(id),
    FOREIGN KEY (local_id) REFERENCES locais(id)
);

INSERT INTO agendamentos (usuario_id, servico_id, local_id, data_agendada, horario, status) VALUES
(3, 1, 1, '2025-12-10', '09:00', 'pendente'),
(4, 3, 3, '2025-11-30', '14:00', 'confirmado'),
(3, 2, 2, '2025-12-05', '08:30', 'concluido');

-- ============================================================
-- Tabela: voluntarios_servicos (voluntários atribuídos)
-- ============================================================
CREATE TABLE voluntarios_servicos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    voluntario_id INT NOT NULL,
    agendamento_id INT NOT NULL,
    confirmado BOOLEAN DEFAULT FALSE,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (voluntario_id) REFERENCES usuarios(id),
    FOREIGN KEY (agendamento_id) REFERENCES agendamentos(id)
);

INSERT INTO voluntarios_servicos (voluntario_id, agendamento_id, confirmado) VALUES
(2, 1, FALSE),
(2, 2, TRUE);

-- ============================================================
-- Tabela: feedback (avaliação dos serviços)
-- ============================================================
CREATE TABLE feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    agendamento_id INT NOT NULL,
    usuario_id INT NOT NULL,
    nota INT CHECK (nota BETWEEN 1 AND 5),
    comentario TEXT,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (agendamento_id) REFERENCES agendamentos(id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

INSERT INTO feedback (agendamento_id, usuario_id, nota, comentario) VALUES
(3, 3, 5, 'Serviço excelente e muito organizado!'),
(2, 4, 4, 'Boa ação comunitária, mas poderia ter mais voluntários.');

-- ============================================================
-- Fim do Dump
-- ============================================================
